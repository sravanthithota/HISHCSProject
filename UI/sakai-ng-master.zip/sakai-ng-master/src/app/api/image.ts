export interface Image {
    previewImageSrc?;
    thumbnailImageSrc?;
    alt?;
    title?;
}
