import { Component } from '@angular/core';

@Component({
    templateUrl: './documentation.component.html'
})
export class DocumentationComponent {}
