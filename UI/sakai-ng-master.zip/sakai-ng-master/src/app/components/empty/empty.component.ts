import { Component } from '@angular/core';

@Component({
    templateUrl: './empty.component.html'
})
export class EmptyComponent {}
